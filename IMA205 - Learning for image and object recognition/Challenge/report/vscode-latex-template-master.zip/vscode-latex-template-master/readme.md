# LaTeX VSCode IEEE Template

## Requirements

Same requirements with [latex-workshop](https://marketplace.visualstudio.com/items?itemName=James-Yu.latex-workshop).

MikTeX recommended for Windows users.

## Usage

Modify `document.tex` and `mybib.bib` as needed.

Build using `pdflatex -> bibtex -> pdflatex -> pdflatex`
